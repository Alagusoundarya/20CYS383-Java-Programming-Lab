package com.amrita.jpl.cys21005.pract.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * @author Alagu Soundarya G
 * @version 1.0
 * Quiz Client Program did for practice
 */

public class QuizClient {
    public static void main(String[] args) {
        try {
            Socket questionPanelSocket = new Socket("localhost", 12345);
            System.out.println("Connected to Quiz Server for the Question Panel.");

            Socket answerPanelSocket = new Socket("localhost", 12345);
            System.out.println("Connected to Quiz Server for the Answer Panel.");

            BufferedReader questionReader = new BufferedReader(new InputStreamReader(System.in));
            PrintWriter questionWriter = new PrintWriter(questionPanelSocket.getOutputStream(), true);

            BufferedReader answerReader = new BufferedReader(new InputStreamReader(answerPanelSocket.getInputStream()));

            String question;
            String answer;

            do {
                System.out.print("Enter a question (or 'exit' to quit): ");
                question = questionReader.readLine();

                if (question != null && !question.isEmpty()) {
                    // Send the question to the server
                    questionWriter.println(question);

                    if (!question.equalsIgnoreCase("exit")) {
                        // Receive the answer from the server
                        answer = answerReader.readLine();
                        System.out.println("Answer: " + answer);
                    }
                }
            } while (!question.equalsIgnoreCase("exit"));

            System.out.println("Quiz Client is shutting down...");
            questionPanelSocket.close();
            answerPanelSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
