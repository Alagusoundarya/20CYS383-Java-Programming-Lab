package com.amrita.jpl.cys21005.pract.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author Alagu Soundarya G
 * @version 1.0
 * Quiz Server Program did for practice
 */

public class QuizServer {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(12345);

            System.out.println("Quiz Server is running...");

            Socket questionPanelSocket = serverSocket.accept();
            System.out.println("Question Panel connected.");

            Socket answerPanelSocket = serverSocket.accept();
            System.out.println("Answer Panel connected.");

            BufferedReader questionReader = new BufferedReader(new InputStreamReader(questionPanelSocket.getInputStream()));
            PrintWriter answerWriter = new PrintWriter(answerPanelSocket.getOutputStream(), true);

            String question;
            String answer;

            do {
                question = questionReader.readLine();

                if (question != null && !question.isEmpty()) {
                    System.out.println("Received question: " + question);

                    // Process the question and determine the answer
                    answer = processQuestion(question);

                    // Send the answer to the answer panel
                    answerWriter.println(answer);
                    System.out.println("Sent answer: " + answer);
                }
            } while (question != null && !question.isEmpty());

            System.out.println("Quiz Server is shutting down...");
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String processQuestion(String question) {
        // Process the question and determine the answer
        // This is just a sample implementation, you can modify it as per your requirements
        if (question.equalsIgnoreCase("What is the capital of India?")) {
            return "Delhi";
        } else if (question.equalsIgnoreCase("Who is the Prime Minister of India'?")) {
            return "Narendra Modi";
        } else if (question.equalsIgnoreCase("Who is the chairperson of G20?")) {
            return "Shri Mata Amritanandamayi Devi";
        } else {
            return "Unknown question";
        }
    }
}